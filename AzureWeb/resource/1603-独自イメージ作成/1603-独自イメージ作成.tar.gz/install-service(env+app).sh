#!/bin/bash
# -------------------------------------------------------------------
# Install application services
# -------------------------------------------------------------------

# Install "load-params"
# ---------------------------------
INITENV_NAME="load-params"
INITENV_SHELL="/etc/rc.d/${INITENV_NAME}.sh"
INITENV_SERVICE="/etc/systemd/system/${INITENV_NAME}.service"

# Install initialize environments shell script.
rm -rf "${INITENV_SHELL}" "${INITENV_SERVICE}"
cp "${INITENV_SHELL##*/}" "${INITENV_SHELL}"
chmod +x "${INITENV_SHELL}"

# Install load systems parameter service.
cp "${INITENV_SERVICE##*/}" "${INITENV_SERVICE}"
chmod +x "${INITENV_SERVICE}"
systemctl daemon-reload
systemctl enable ${INITENV_NAME}
systemctl start ${INITENV_NAME}


# Install "tastylog"
# ---------------------------------
APP_NAME="tastylog"
APP_SERVICE="/etc/systemd/system/${APP_NAME}.service"
APP_WORKDIR="/opt/tastylog"

# Install tastylog application.
rm -rf "${APP_WORKDIR}"
mkdir -p "${APP_WORKDIR}"
mkdir -p "${APP_WORKDIR}/logs"
chmod +x "${APP_WORKDIR}/logs"

# Install application service
rm -rf "${APP_SERVICE}"
cp "${APP_SERVICE##*/}" "${APP_SERVICE}"
chmod +x "${APP_SERVICE}"
systemctl daemon-reload

