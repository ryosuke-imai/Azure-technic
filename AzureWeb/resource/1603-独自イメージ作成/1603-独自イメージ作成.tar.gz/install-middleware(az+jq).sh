#!/bin/bash
# -------------------------------------------------------------------
# Install middleware
# -------------------------------------------------------------------

# Install az cli
# ---------------------------------
rpm --import https://packages.microsoft.com/keys/microsoft.asc

cat > "/etc/yum.repos.d/azure-cli.repo" <<EOF
[azure-cli]
name=Azure CLI
baseurl=https://packages.microsoft.com/yumrepos/azure-cli
enabled=1
gpgcheck=1
gpgkey=https://packages.microsoft.com/keys/microsoft.asc
EOF

yum install -y azure-cli


# Install jq
# ---------------------------------
curl -o /usr/local/bin/jq -L https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64
chmod +x /usr/local/bin/jq
