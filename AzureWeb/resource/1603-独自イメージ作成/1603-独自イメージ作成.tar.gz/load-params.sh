#!/bin/bash

# Environment variables file name
SETENV_SHELL="/etc/profile.d/load-params.sh"
APPENV_FILE="/etc/params"

# Login to Azure using Manged Identity
az login --identity --allow-no-subscription > /dev/null

# Load environment info
METADATA=$(curl -H Metadata:true --noproxy "*" "http://169.254.169.254/metadata/instance?api-version=2021-02-01")
VM_PROJECT=$(echo $METADATA | jq -r '.compute.tagsList[] | select(.name == "Project") | .value')
VM_ENV=$(echo $METADATA | jq -r '.compute.tagsList[] | select(.name == "Env") | .value')
KEY_VAULT_NAME=$(echo $METADATA | jq -r '.compute.tagsList[] | select(.name == "KEY_VAULT_NAME") | .value')

# Create KeyVault name
if [ "$KEY_VAULT_NAME" = "" ]; then
  KEY_VAULT_NAME=${VM_PROJECT}-${VM_ENV}-kv
fi

# Load & output environmental variables
SECRET_LIST=$(az keyvault secret list --vault-name ${KEY_VAULT_NAME} --query "[*].name")

# Output environment initialize scripts.
cat > "${SETENV_SHELL}" <<EOF
#
# [$(date '+%Y-%m-%dT%H:%M:%S+09:00' -d '9 hour')] Initialized scripts.
#
export VM_PROJECT="${VM_PROJECT}"
export VM_ENV="${VM_ENV}"
export KEY_VAULT_NAME="${KEY_VAULT_NAME}"
EOF

for SECRET_NAME in $(echo ${SECRET_LIST} | /usr/local/bin/jq -r ".[]"); do
  SECRET_VALUE=$(az keyvault secret show --vault-name ${KEY_VAULT_NAME} --name ${SECRET_NAME} --query "value")
  SECRET_KEY=$(echo ${SECRET_NAME^^} | sed -e "s/-/_/g")
  echo "export ${SECRET_KEY}=${SECRET_VALUE}"
done >> "${SETENV_SHELL}"

# Output environment file.
mkdir -p ${APPENV_FILE%/*}
sed "s/^export //g" ${SETENV_SHELL} > ${APPENV_FILE}

# Load environments.
chmod +x "${SETENV_SHELL}"
source "${SETENV_SHELL}"
