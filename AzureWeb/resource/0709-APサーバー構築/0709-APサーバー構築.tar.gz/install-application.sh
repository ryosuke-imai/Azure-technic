#!/bin/bash
# -------------------------------------------------------------------
# Install application
# -------------------------------------------------------------------
APP_NAME="tastylog"
APP_SERVICE="/etc/systemd/system/${APP_NAME}.service"
APP_WORKDIR="/opt/tastylog"

# Install tastylog application.
rm -rf "${APP_WORKDIR}"
mkdir -p "${APP_WORKDIR}"
mkdir -p "${APP_WORKDIR}/logs"
cp "${APP_NAME}" "${APP_WORKDIR}"
chmod +x "${APP_WORKDIR}/${APP_NAME}"
chmod +x "${APP_WORKDIR}/logs"

# Execute application
systemctl daemon-reload
systemctl enable tastylog
systemctl start tastylog
